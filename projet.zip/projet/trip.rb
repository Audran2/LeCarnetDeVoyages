class Trip < ApplicationRecord
    belongs_to :user
end
