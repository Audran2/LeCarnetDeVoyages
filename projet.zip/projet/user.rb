class User < ApplicationRecord
    has_many :trips
end
